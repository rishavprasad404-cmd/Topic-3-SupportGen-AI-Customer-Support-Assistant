"""Tests the Gemini-mode logic (analyze -> tool call -> verify -> escalate) with a fake LLM,
so no API key or network is needed. Real API behaviour must be checked manually with run_eval.py."""
import json
import pathlib
import sys
import zlib

import numpy as np
import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import agent as agent_mod  # noqa: E402
import tools  # noqa: E402
from rag import KnowledgeBase, _tokens, read_file  # noqa: E402

DOCS = pathlib.Path(__file__).resolve().parents[1] / "data" / "sample_docs"


class FakeLLM:
    def __init__(self, confidence=0.9, grounded=True, fail_on=None, fail_embed=False):
        self.confidence, self.grounded, self.fail_on, self.fail_embed = confidence, grounded, fail_on, fail_embed

    def embed(self, texts, query=False):
        if self.fail_embed:
            raise RuntimeError("quota exceeded")
        out = []
        for t in texts:  # hashed bag-of-words stand-in for real embeddings
            v = np.zeros(128)
            for tok in _tokens(t):
                v[zlib.crc32(tok.encode()) % 128] += 1
            out.append(v.tolist())
        return out

    def generate(self, prompt, system=None, tools=None, json_mode=False, temperature=0.2):
        if self.fail_on and self.fail_on in prompt:
            raise RuntimeError("503 model overloaded")
        if "Classify the latest customer message" in prompt:
            return json.dumps({"intent": "faq", "sentiment": "neutral", "standalone_question": "return window length"})
        if "strict QA auditor" in prompt:
            return "```json\n" + json.dumps({"grounded": self.grounded, "confidence": self.confidence, "issue": "test"}) + "\n```"
        if tools:  # simulate Gemini deciding to call the order tool
            tools[0]("SG1003")
        return "You can return items within 30 days of delivery [1]."


@pytest.fixture()
def make_agent(tmp_path, monkeypatch):
    monkeypatch.setitem(agent_mod.MIN_RETRIEVAL, "gemini", 0.05)  # fake embeddings are weak

    def build(llm):
        kb = KnowledgeBase(llm)
        for f in sorted(DOCS.glob("*.md")):
            kb.add_document(f.name, read_file(f))
        return agent_mod.Agent(kb, llm, tools.TicketStore(tmp_path / "t.json"))
    return build


def test_confident_answer_is_returned_with_sources_and_tool_trace(make_agent):
    r = make_agent(FakeLLM(confidence=0.9)).handle("s", "What is the return window?")
    assert not r["escalated"] and r["confidence"] == 0.9 and r["sources"] and r["mode"] == "gemini"
    assert any(s["step"] == "tool call" for s in r["steps"])


def test_low_confidence_escalates(make_agent):
    r = make_agent(FakeLLM(confidence=0.3)).handle("s", "What is the return window?")
    assert r["escalated"] and r["ticket_id"]


def test_ungrounded_answer_is_capped_and_escalates(make_agent):
    r = make_agent(FakeLLM(confidence=0.95, grounded=False)).handle("s", "What is the return window?")
    assert r["escalated"]  # confidence capped at 0.4 when the auditor says not grounded


def test_api_outage_escalates_instead_of_crashing(make_agent):
    r = make_agent(FakeLLM(fail_on="CONTEXT:")).handle("s", "What is the return window?")
    assert r["escalated"]


def test_embedding_failure_falls_back_to_tfidf(make_agent):
    ag = make_agent(FakeLLM(fail_embed=True))
    assert ag.kb.mode == "tfidf"
    assert ag.handle("s", "How many days to return an item?")["sources"]
