"""Run with:  pytest -q      (uses the offline pipeline, so no API key or network is needed)"""
import io
import pathlib
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from app import create_app  # noqa: E402
from rag import chunk_text  # noqa: E402


@pytest.fixture()
def client(tmp_path):
    return create_app(offline=True, workdir=tmp_path).test_client()


def ask(c, msg, sid="t1"):
    r = c.post("/api/chat", json={"message": msg, "session_id": sid})
    assert r.status_code == 200
    return r.get_json()


def test_faq_answered_from_policy_with_source(client):
    r = ask(client, "What is your return policy?")
    assert not r["escalated"] and "30 days" in r["answer"]
    assert r["sources"][0]["source"] == "refund_policy.md"


def test_product_question(client):
    r = ask(client, "How do I factory reset my SphereBuds Pro?")
    assert not r["escalated"] and "10 seconds" in r["answer"]


def test_order_lookup_uses_tool(client):
    r = ask(client, "Where is my order SG1002?")
    assert "In transit" in r["answer"] and any(s["step"] == "tool call" for s in r["steps"])


def test_order_id_remembered_across_turns(client):
    ask(client, "Where is my order?", "s2")           # bot asks for the ID
    assert "In transit" in ask(client, "SG1002", "s2")["answer"]


def test_unknown_order_is_handled_without_escalation(client):
    r = ask(client, "Track order SG9999")
    assert "couldn't find" in r["answer"] and not r["escalated"]


def test_unanswerable_question_escalates_with_ticket(client):
    r = ask(client, "Do you sell electric scooters with a 500 km range?")
    assert r["escalated"] and r["ticket_id"]
    assert client.get("/api/tickets").get_json()[0]["id"] == r["ticket_id"]


def test_human_request_is_high_priority(client):
    r = ask(client, "I want to talk to a human agent")
    assert r["escalated"]
    assert client.get("/api/tickets").get_json()[0]["priority"] == "high"


def test_resolve_ticket(client):
    tid = ask(client, "I want to speak to a manager")["ticket_id"]
    assert client.post(f"/api/tickets/{tid}/resolve").get_json()["status"] == "resolved"
    assert client.post("/api/tickets/NOPE/resolve").status_code == 404


def test_uploaded_document_becomes_searchable(client):
    doc = b"# Store hours\n\nOur Kolkata flagship store is open from 10 am to 8 pm on weekdays and closed on Sundays."
    assert client.post("/api/upload", data={"file": (io.BytesIO(doc), "store.md")}).status_code == 200
    r = ask(client, "What time does the Kolkata store open?")
    assert not r["escalated"] and r["sources"][0]["source"] == "store.md"


def test_input_validation(client):
    assert client.post("/api/chat", json={"message": "   "}).status_code == 400
    assert client.post("/api/chat", json={"message": "x" * 1001}).status_code == 400
    bad = client.post("/api/upload", data={"file": (io.BytesIO(b"MZ"), "virus.exe")})
    assert bad.status_code == 400


def test_chunking_keeps_headings_separate_and_splits_long_text():
    chunks = chunk_text("## A\nfirst answer\n\n## B\nsecond answer", "x.md")
    assert len(chunks) == 2
    assert len(chunk_text("word " * 500, "long.txt")) > 3
