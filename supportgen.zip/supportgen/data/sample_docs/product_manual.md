# SphereBuds Pro User Manual

## Pairing
Open the charging case lid and hold the case button for 3 seconds until the LED flashes white. Then select "SphereBuds Pro" in your phone's Bluetooth settings.

## Factory reset
Place both earbuds in the case with the lid open. Press and hold the case button for 10 seconds until the LED flashes red three times. Remove "SphereBuds Pro" from your Bluetooth list and pair again.

## Battery life
The earbuds last 8 hours per charge with noise cancellation off and 6 hours with it on. The case provides 24 extra hours. A 10 minute fast charge gives about 2 hours of playback.

## Water and sweat resistance
SphereBuds Pro are rated IPX4, which protects against sweat and splashes. They are not designed for swimming or showering.

## Noise cancellation modes
Tap and hold either earbud to cycle between Noise Cancellation, Transparency and Off. Modes can be customised in the SphereBuds app.

## One earbud not working
Put both earbuds in the case for 10 seconds, then perform the factory reset and re-pair. If one earbud still has no sound, it may be defective and is covered by the 12-month warranty.

## LED status guide
White flashing means pairing mode. Solid green means the case is fully charged. Amber means the battery is below 20 percent. Red flashing three times confirms a factory reset.
