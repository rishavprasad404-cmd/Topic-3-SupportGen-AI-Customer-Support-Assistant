# Returns, Refunds and Warranty Policy

## Return window
Items can be returned within 30 days of the delivery date if they are unused and in original packaging. Returns requested after 30 days are not accepted, except for warranty claims.

## Items that cannot be returned
Gift cards and digital products are not returnable. For hygiene reasons, opened in-ear products such as earbuds and ear tips can only be returned if they are defective.

## Refund timeline and method
Refunds are issued to the original payment method within 5 to 7 business days after our warehouse receives the item. Cash on delivery orders are refunded by UPI or bank transfer to the account you provide.

## Return shipping cost
Return pickup is free for defective, damaged or wrong items. For other returns a pickup fee of Rs 99 is deducted from the refund.

## Exchanges
You get one free exchange per order for size or colour within 30 days of delivery, subject to stock availability.

## Warranty
All ShopSphere electronics carry a 12-month warranty from the delivery date against manufacturing defects. The warranty does not cover water damage beyond the rated protection, physical damage or unauthorised repairs. Extended warranty of 24 months can be bought for Rs 499 within 30 days of delivery.
