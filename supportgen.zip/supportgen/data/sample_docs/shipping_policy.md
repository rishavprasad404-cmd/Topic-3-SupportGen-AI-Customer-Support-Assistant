# Shipping Policy

## Delivery speed and cost
Standard delivery takes 3 to 7 business days. Express delivery takes 1 to 2 business days in metro cities and costs Rs 149. Shipping is free on orders above Rs 999; otherwise standard shipping costs Rs 59.

## Dispatch time
Orders placed before 2 pm IST on a working day are dispatched the same day. Orders placed later are dispatched the next working day.

## International shipping
We ship to the USA, UK, UAE and Singapore. International delivery takes 7 to 14 business days. Customs duties and import taxes are paid by the customer.

## Failed delivery
The courier makes up to 3 delivery attempts. After the third failed attempt the parcel is returned to our warehouse and the order is refunded minus shipping charges.

## Delayed orders
If your order is more than 3 business days late, contact support with your order ID so we can open a courier investigation.
