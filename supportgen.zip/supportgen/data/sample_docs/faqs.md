# ShopSphere FAQ

## How do I track my order?
Log in and open "My Orders", or tell SupportGen your order ID (format SG1234). A tracking link is emailed as soon as the order ships.

## Can I change or cancel an order?
Orders can be edited or cancelled from "My Orders" within 2 hours of placing them. After that the order moves to packing and can no longer be changed, but you can still return it after delivery.

## What payment methods do you accept?
We accept UPI, credit and debit cards, net banking, popular wallets, and cash on delivery for orders up to Rs 20,000. EMI is available on orders above Rs 5,000 with selected cards.

## How do I reset my account password?
Choose "Forgot password" on the login page and enter your email. The reset link is valid for 30 minutes. Check your spam folder if it does not arrive.

## How can I contact a human agent?
SupportGen chat is available 24/7. Human agents are available Monday to Saturday, 9 am to 8 pm IST, at support@shopsphere.example.

## Do you offer gift wrapping?
Yes. Gift wrapping costs Rs 49 per item and can be added at checkout. Gift receipts hide the price.
