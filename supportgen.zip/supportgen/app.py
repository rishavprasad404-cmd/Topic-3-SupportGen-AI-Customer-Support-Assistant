"""SupportGen - Flask backend.   Run:  python app.py   then open http://localhost:5000"""
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from werkzeug.utils import secure_filename

import tools
from agent import THRESHOLD, Agent
from rag import SUPPORTED, KnowledgeBase, read_file

BASE = Path(__file__).parent
load_dotenv(BASE / ".env")
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")


def create_app(offline=False, workdir=None):
    """offline=True ignores any API key (used by tests); workdir holds uploads + tickets."""
    work = Path(workdir or BASE / "data")
    uploads = work / "uploads"
    uploads.mkdir(parents=True, exist_ok=True)

    llm, key = None, None if offline else (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
    if key:
        try:
            from llm import Gemini
            llm = Gemini(key)
        except Exception as e:
            logging.warning("Gemini unavailable (%s) - running in offline mode", e)

    kb = KnowledgeBase(llm)
    for f in sorted([*(BASE / "data" / "sample_docs").glob("*"), *uploads.glob("*")]):
        if f.suffix.lower() in SUPPORTED:
            kb.add_document(f.name, read_file(f))
    agent = Agent(kb, llm, tools.TicketStore(work / "tickets.json"))

    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB uploads

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/status")
    def status():
        return jsonify(mode=agent.mode, search=kb.mode, threshold=THRESHOLD, documents=kb.docs())

    @app.post("/api/chat")
    def chat():
        d = request.get_json(silent=True) or {}
        msg = (d.get("message") or "").strip()
        if not msg:
            return jsonify(error="Message is empty"), 400
        if len(msg) > 1000:
            return jsonify(error="Message too long (max 1000 characters)"), 400
        return jsonify(agent.handle(d.get("session_id") or "default", msg, (d.get("email") or "")[:120]))

    @app.post("/api/upload")
    def upload():
        f = request.files.get("file")
        if not f or not f.filename:
            return jsonify(error="No file provided"), 400
        name = secure_filename(f.filename)
        if Path(name).suffix.lower() not in SUPPORTED:
            return jsonify(error="Unsupported file type. Upload a .txt, .md or .pdf file."), 400
        path = uploads / name
        f.save(path)
        try:
            n = kb.add_document(name, read_file(path))
        except Exception as e:
            path.unlink(missing_ok=True)
            return jsonify(error=f"Could not read document: {e}"), 400
        return jsonify(name=name, chunks=n)

    @app.get("/api/documents")
    def documents():
        return jsonify(kb.docs())

    @app.delete("/api/documents/<name>")
    def delete_document(name):
        removed = kb.remove_document(name)
        (uploads / secure_filename(name)).unlink(missing_ok=True)
        return jsonify(removed_chunks=removed)

    @app.get("/api/tickets")
    def list_tickets():
        return jsonify(agent.tickets.list())

    @app.post("/api/tickets/<ticket_id>/resolve")
    def resolve_ticket(ticket_id):
        t = agent.tickets.resolve(ticket_id)
        return (jsonify(t), 200) if t else (jsonify(error="Ticket not found"), 404)

    @app.errorhandler(413)
    def too_large(_):
        return jsonify(error="File too large (max 10 MB)"), 413

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000, debug=False)
